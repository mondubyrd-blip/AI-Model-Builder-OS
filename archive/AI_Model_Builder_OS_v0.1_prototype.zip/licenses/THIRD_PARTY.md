# Third-party license inventory

Populate this file as packages are pinned.

Required fields:
- component
- version/commit
- license
- source
- build options
- redistribution obligations
