# aibuilder package

Future Buildroot package for:
- node capability discovery
- orchestration
- provenance
- local dashboard
- model lifecycle commands
