# AI Model Builder OS — v0.1 Prototype

Purpose: a bootable-appliance prototype for turning commodity x86_64 hardware into a dedicated AI model-builder node.

This is **not yet the final Buildroot ISO**. v0.1 is the reproducible project skeleton used to validate the architecture safely before touching the Ryzen 9.

Target test order:
1. Peppy
2. Acer R11
3. Dell AIO
4. HP ENVY T301 + dedicated GPU
5. Ryzen 9 8945HS

Design:
UEFI -> minimal Linux/Buildroot -> hardware discovery -> AI Builder services -> local dashboard

The prototype deliberately keeps the normal OS intact. It is intended to be developed/tested first in a VM or disposable USB environment.

## Directory layout

- `configs/` target profiles
- `board/` board-specific files
- `package/` AI Builder packages/services
- `rootfs-overlay/` immutable root filesystem additions
- `scripts/` build/test utilities
- `docs/` architecture and provenance notes
- `data/` runtime mount layout
- `licenses/` third-party license inventory placeholder

## v0.1 scope

- x86_64 appliance architecture
- hardware capability discovery
- CPU/GPU/NPU inventory where discoverable through Linux interfaces
- model/dataset/artifact directory convention
- local-only dashboard service
- provenance manifest format
- reversible boot design
- no cloud dependency
- no automatic model training
- no destructive disk operations

## Important

This prototype does not claim that every NPU is usable for every AI workload. Accelerator support is hardware/backend dependent.

It also does not make an ownership claim about AI-generated synthetic data. Every dataset/model should carry provenance and applicable license/terms information.
