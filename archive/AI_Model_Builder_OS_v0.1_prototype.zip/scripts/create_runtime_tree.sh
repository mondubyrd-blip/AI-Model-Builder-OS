#!/bin/sh
set -eu
ROOT="${1:-/var/lib/aibuilder}"
mkdir -p "$ROOT"/{base-models,datasets,tokenizers,training,checkpoints,adapters,quantization,evaluation,exports,logs,hardware,workspace,manifests}
echo "Created AI Builder runtime tree at $ROOT"
