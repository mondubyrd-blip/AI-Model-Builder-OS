#!/bin/sh
set -eu
echo "=== AI BUILDER HARDWARE PROBE ==="
echo
echo "[CPU]"
grep -m1 'model name' /proc/cpuinfo 2>/dev/null || true
echo
echo "[MEMORY]"
awk '/MemTotal/ {print $0}' /proc/meminfo 2>/dev/null || true
echo
echo "[PCI]"
if command -v lspci >/dev/null 2>&1; then
  lspci 2>/dev/null | grep -Ei 'VGA|3D|Display|Processing accelerators|NPU|AI' || true
else
  echo "lspci unavailable in this prototype environment"
fi
echo
echo "[DMI]"
if command -v dmidecode >/dev/null 2>&1; then
  dmidecode -s system-product-name 2>/dev/null || true
  dmidecode -s system-manufacturer 2>/dev/null || true
fi
echo
echo "[DRM]"
ls -1 /sys/class/drm 2>/dev/null || true
echo
echo "[ACCELERATORS]"
ls -la /dev/accel 2>/dev/null || echo "No /dev/accel interface exposed"
